import sys

# GAME WINDOW CONSTANTS
WINDOW_WIDTH = 480
DESKTOP_WINDOW_HEIGHT = 640
MIN_WINDOW_HEIGHT = 640
MAX_WINDOW_HEIGHT = 1100


def _web_window_height():
    """In the browser, match the canvas shape to the screen so the game fills it."""
    try:
        from platform import window  # pygbag's bridge to the browser

        ratio = int(window.innerHeight) / int(window.innerWidth)
        height = int(WINDOW_WIDTH * ratio)
        return max(MIN_WINDOW_HEIGHT, min(MAX_WINDOW_HEIGHT, height))
    except Exception:
        return 854


if sys.platform == "emscripten":
    WINDOW_HEIGHT = _web_window_height()
else:
    WINDOW_HEIGHT = DESKTOP_WINDOW_HEIGHT

FPS = 60
BG_COLOR = (10, 10, 30)
WINDOW_CAPTION = "SPACE SHOOTER"

# FONT AND TEXT CONSTANTS
FONT_SIZE = 40
TEXT_COLOR = "white"

# HUD CONSTANTS
HUD_COLOR = "white"
HUD_MARGIN = 10

# PAUSE BUTTON AND OVERLAY CONSTANTS
PAUSE_BUTTON_SIZE = 56
PAUSE_BUTTON_TOP = 50
PAUSE_BUTTON_PADDING = 10
PAUSE_BUTTON_ALPHA = 150
PAUSE_DIM_ALPHA = 140

# BUTTON CONSTANTS
BUTTON_WIDTH = 400
BUTTON_HEIGHT = 60
BUTTON_COLOR = "royalblue"
PLAY_BUTTON_Y = WINDOW_HEIGHT * 4 // 5

# MENU AND GAME OVER SCREEN CONSTANTS
TITLE_FONT_SIZE = 56
SMALL_FONT_SIZE = 28
TITLE_Y = WINDOW_HEIGHT // 6
PANEL_WIDTH = 400
PANEL_HEIGHT = 280
PANEL_CENTER_Y = WINDOW_HEIGHT // 2 - 20
PANEL_COLOR = (10, 10, 30)
PANEL_ALPHA = 190
ACCENT_COLOR = "gold"
LINE_SPACING = 32
HOW_TO_PLAY_LINES = (
    "Move: arrow keys or A / D",
    "Shoot: hold Space",
    "Touch: hold to move and shoot",
    "Pause: P or the || button",
    "Enemies that pass you cost a life!",
)

# HIT FEEDBACK CONSTANTS
HIT_FLASH_TIME = 0.5
HIT_FLASH_ALPHA = 110
HIT_FLASH_COLOR = "red"

# PLAYER CONSTANTS
PLAYER_WIDTH = 50
PLAYER_HEIGHT = 50
PLAYER_START_X = WINDOW_WIDTH // 2
PLAYER_BOTTOM_MARGIN = 50
PLAYER_START_Y = WINDOW_HEIGHT - PLAYER_BOTTOM_MARGIN
PLAYER_COLOR = "cyan"
PLAYER_SPEED = 300
PLAYER_SHOOT_COOLDOWN = 0.15
PLAYER_MAX_LIVES = 10
TOUCH_DEADZONE = 8

# BULLET CONSTANTS
BULLET_WIDTH = 8
BULLET_HEIGHT = 24
BULLET_COLOR = "red"
BULLET_SPEED = 700

# ENEMY CONSTANTS
ENEMY_WIDTH = 40
ENEMY_HEIGHT = 40
ENEMY_COLOR = "orange"
ENEMY_SPEED = 200
ENEMY_SPAWN_INTERVAL = 1.0
ENEMY_SPAWN_MARGIN = PLAYER_WIDTH // 2

# SCORING CONSTANTS
POINTS_PER_KILL = 10

# DIFFICULTY CONSTANTS
POINTS_PER_LEVEL = 300
LEVEL_MESSAGE_TIME = 1.5
SPAWN_INTERVAL_STEP = 0.09
MIN_SPAWN_INTERVAL = 0.4
ENEMY_SPEED_STEP = 30
MAX_ENEMY_SPEED = 450

# ASSET PATHS
PLAYER_IMAGE = "assets/images/player.png"
BULLET_IMAGE = "assets/images/bullet.png"
ENEMY_IMAGE = "assets/images/enemy.png"
BACKGROUND_IMAGE = "assets/images/background.png"

# SOUND PATHS AND VOLUMES
SHOOT_SOUND = "assets/sounds/shoot.ogg"
EXPLOSION_SOUND = "assets/sounds/explosion.ogg"
HIT_SOUND = "assets/sounds/hit.ogg"
GAME_OVER_SOUND = "assets/sounds/gameover.ogg"
SFX_VOLUME = 0.4
SHOOT_VOLUME = 0.05
EXPLOSION_VOLUME = 0.4

MUSIC = "assets/sounds/music.ogg"
MUSIC_VOLUME = 0.3
